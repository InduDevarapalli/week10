import './App.css';
import { useEffect, useState } from 'react';
import axios from 'axios';
 
function App() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    axios
      .get("https://datausa.io/api/data?drilldowns=Nation&measures=Population")
      .then((result) => {
        console.log(result.data.data);
        setPosts(result.data.data);
      })
      .catch((error) => console.log(error));
  }, []);
 
  return (
    <div>
      <table border="1">
        <thead>
          <tr>
          <th>ID Nation</th>
          <th>Year</th>
          <th>Population</th>
          </tr>
        </thead>
        <tbody>
          {
            posts.map(
              data =>
                <tr key={data.Nation}>
                  <td>{data["ID Nation"]}</td>
                  <td>{data.Year}</td>
                  <td>{data.Population}</td>
                </tr>
            )
          }
        </tbody>
      </table>
    </div>
  );
}
 
export default App;